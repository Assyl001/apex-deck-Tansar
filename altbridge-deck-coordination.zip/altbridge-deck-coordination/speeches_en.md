# Conference Deck — Speeches (English)

For: Tansar Capital Investors Annual Meeting · May 6, 2026
Speaker: Assyl Akhmet (CPO, Altbridge)
Total: 17 slides · ~12–15 minutes

This file contains the speech text for each slide. Approximate timing is shown for each section.

The corresponding HTML slide mockups are in the `conference-deck/mockups/` folder of this archive — open any `slideNN_v5.html` in a browser to view the visual.

---

## Slide 01 — Title / Opening

*[~30-40 seconds. Simple English (B1). Greet, name yourself, set up the journey.]*

Good morning, everyone — and thank you, Tansar, for inviting Altbridge today.

I'm **Assyl Akhmet** — Chief Product Officer at Altbridge. We build infrastructure for what comes after analyst-assistance — **agentic investing on live capital**.

The next twenty minutes are about one journey. **From Level 3 to Level 4.** Level 3 is assisted research — a human approves every trade. Level 4 is agentic execution — humans supervise, not execute.

We started this in **Q1 of last year**. By Q3, we moved to Level 4. The year after gave us results I want to share with you.

But first — let me start with a question you probably know.

*[Click → slide 02]*

---

## Slide 02 — Andrew Ang's LinkedIn quote

*[~35-45 seconds. Simple English (B1). Plant the analogy seed.]*

Six months ago, our Chief Strategist posted this on LinkedIn:

*"How is adopting AI in investments — like driverless cars?"*

That's **Andrew Ang**. Former Head of Systematic Investing at BlackRock. Professor at Columbia Business School. He wrote much of the modern textbook on factor investing — over **thirty-four thousand academic citations**.

When Andrew picks an analogy — listen carefully.

And this analogy is **exact**. The driverless car industry has spent twenty years on one question — *how much of the steering wheel do you give the AI, and when?* That is the same question for investing now.

The answer is a framework. We will get to it. But first — let me show you why we needed it.

*[Click → slide 03]*

---

## Slide 03 — Try this yourself + Failure Mode 1 (merged)

*[Merged slide. ~50-55 seconds. Simple English (B1). Set the prompt → reveal the variance → land the punchline.]*

Right now, on your phone, you can open Claude, ChatGPT, or Perplexity. Type a prompt like this:

*"Analyze NVIDIA as an investment. Build a DCF. What's the fair value per share?"*

Try this. Same prompt. Many times. You will get answers like these.

**$30.8 billion. $28.5 billion. $31.2 billion. $30.6 billion.** All look professional. All sound confident.

The real number — from NVIDIA's 10-Q — is **$30.77 billion**.

Two of these answers are wrong. **You cannot tell which.** The output never cites the 10-Q.

We call this **confident confabulation**. The model invents — confidently. It never tells you when it is making things up.

This is failure mode one of three. Two more failure modes are next.

*[Click → slide 04]*

---

## Slide 04 — Failure Mode 2 · Corner cutting on data

*[~35-45 seconds. B1 + CPO frame. Abstract / qualitative — no specific percentages or paper citations.]*

Failure mode two. **The model takes shortcuts.**

A 10-K is around **200 pages**. When LLMs are tested on real 10-Ks, only a small part of the document is actually used. Most of it is **skipped** — or filled in from what the model already knew.

Look at this slide. The cyan cells show what the model used. The gray cells — skipped, or built from what the model **already knew** about similar companies. **The output never tells you which is which.**

So your DCF looks complete. But most of it is built on **prior knowledge** — not on the actual report.

That's failure mode two. **Failure mode three is the worst.**

*[Click → slide 05]*

---

## Slide 05 — Failure Mode 3 · No normalization

*[~45-55 seconds. B1 + CPO frame. The silent killer.]*

Failure mode three. **No normalization.**

This one is the most expensive. And almost nobody talks about it.

Here is what every analyst learns in their first week — but the LLM does not. When a company reports earnings, the headline number is **not a baseline**. It includes **one-time items**. Asset sales. Legal settlements. Restructuring charges.

When you build a forward projection — a DCF that estimates future cash flows — you have to **normalize**. You take out one-time items. You project from a clean baseline.

The LLM does not do this. It reads $62 billion in net income, and it projects $62 billion forward. But in this $62 billion, there is **$4 billion** from a one-time asset sale. **$2 billion** in legal settlements. **Negative $3 billion** in restructuring.

The real recurring number is closer to **$59 billion**.

So the LLM's "fair value" is built on a number that **by definition will not happen again**. Headline net income is a **result**. Not a **baseline**.

This is failure mode three. And it is the silent one — because the output looks completely normal.

*[Click → slide 06]*

---

## Slide 06 — The L0-L5 Framework (merged)

*[~50-60 seconds. The mental-model reveal.]*

Now — the framework Andrew was talking about.

Last September, Andrew Ang and our research team published a paper. They took the **L0 to L5** model from autonomous driving — the same model used to classify Tesla's Autopilot or Waymo — and applied it to investing.

Six levels. From **L0** — no automation — to **L5** — full autonomy with no human in the loop at all.

Most of the industry today — most of what is sold as *"AI in finance"* — sits at **L1 or L2**. ChatGPT wrappers. Factor-model black boxes. *"AI-powered"* rebranding of tools that already existed.

**L3** is where the industry can credibly be today. AI that recommends decisions in a defined domain. Humans on the loop, supervising.

**L4** — **High Automation**. Full autonomy in a defined domain. Rare. It needs architectural discipline — **pipelines, not just prompts**.

That is where Altbridge sits today. **L4. On live capital. Since Q3 of last year.**

**L5** — full autonomy across all market conditions — is theoretical. Decades away in any serious read.

So when you hear *"AI in finance"* — ask which level. Most of what is sold is **L1**. We are at **L4**. **The gap matters.**

*[Click → slide 07]*

---

## Slide 07 — Our first live deployment

*[~45-55 seconds. From framework theory to lived practice.]*

Now — what we ran.

In Q1 of last year, we deployed a **Level 3** system. US and China equities. Value approach. The system used conviction scoring, DCF modeling, and sector-routed frameworks. But on every recommendation, a PM had to approve.

Through Q3, that is how we ran. **AI proposing — humans approving.**

Then in Q3, we made the transition. We **cut the cord**. The system moved to **L4** — autonomy in a defined domain. Humans monitoring instead of approving.

This is the part that matters. The **L3 to L4 transition** is not theory from a paper. It is what we lived through in real time. With real money. On live capital.

It was the **first proof point** that the framework describes something real.

*[Click → slide 08]*

---

## Slide 08 — 2025 Full-Year Performance

*[~45-55 seconds. The numbers that matter to LP audience.]*

Phase one results. 2025 full year. Live capital.

**Plus thirty-three percent** gross return. That is the headline.

**Sharpe ratio of 2.28.** Above most long-short hedge funds.

**Max drawdown of negative five percent.** Contained by the structured pipeline.

**Plus fourteen percentage points** above the S&P 500 in 2025. **Plus twenty-three** above Citadel — a leading systematic fund.

Capital grew from **four hundred and ninety thousand** to **six hundred and fifty thousand**. No outside money. No leverage. No derivatives.

US and China equities. Value approach. A **disciplined pipeline** — not a black box.

*[Click → slide 09]*

---

## Slide 09 — Intellectual reset with Andrew Ang

*[~50-60 seconds. Pivot moment — from Phase 1 success to Phase 2 mental model.]*

After Phase 1 worked, we did something different. We sat down with Andrew Ang.

Our research team — with Andrew — published the L0 to L5 paper you just saw. And one sentence from that work changed everything for us.

Andrew put it this way: **the bottleneck is the human bandwidth.**

The full sentence is on the slide. The simple version: **not data. Not the model. The human.** There are only so many decisions a person can make in a day.

That changed our goal. Not *"remove the human."* Not *"AI replaces the team."* But: **give the team more bandwidth**. Supervise more — more efficiently. **More** governance, not less.

From this point, we stopped chasing **L5**. We started chasing **L4 at scale**.

*[Click → slide 10]*

---

## Slide 10 — The Self-Driving Portfolio

*[~50-60 seconds. The architectural answer to "L4 at scale".]*

While Phase 1 was running, we were already building **Phase 2**. Bigger.

Phase 2 is not stock picking. It is **strategic asset allocation** — how a fund decides where to put money across all asset classes.

This is the second paper from our team — again with Andrew Ang. **The Self-Driving Portfolio.**

The system has about **fifty agents**. They produce market assumptions. They run **twenty different methods** for building portfolios. They debate. They peer-review. They vote on each other's work.

One **meta-agent** watches everything. It compares forecasts with real returns. It rewrites the other agents' code overnight to make them better next time.

All of this is governed by one document — the **Investment Policy Statement**, the IPS. The same document that guides a human portfolio manager now directs the AI.

The investor's job changes. You stop doing every step yourself. You design the system that does the steps. From **executor** — to **architect**.

*[Click → slide 11]*

---

## Slide 11 — 30-year academic validation

*[~30-40 seconds. Backtest credibility — short, factual.]*

We tested the Self-Driving Portfolio against **thirty years** of real market data. **2001** — the dot-com crash. **2008** — the global financial crisis. **2020** — COVID.

The system held up.

Sharpe ratio **0.39** — about the same as a traditional sixty-forty portfolio. **Sixty percent stocks. Forty percent bonds.**

But maximum drawdown of **negative twenty-five point six percent** — versus negative **thirty-four point three** for sixty-forty. Significantly less pain in the worst moments.

The system did not break in any of the three crises. That is the validation we wanted before scaling up.

*[Click → slide 12]*

---

## Slide 12 — Apex architecture: Black box vs. structured pipeline

*[~60-70 seconds. Architectural deep-dive. CPO domain — speak with confidence.]*

Now — how Apex actually works.

On the **left** — what most "AI in finance" looks like. You ask the model. You get an answer. **Black box.** No source for any cell. No way to check.

On the **right** — the **Apex pipeline**. The same task is decomposed into about **two hundred small atomic rows**. Each row has a value, a source, and a validator. You can see one example on the slide.

Every cell. Every time. If the validator fails, the cell is blocked, retried, or escalated to a human.

This is how we solve the **three failure modes** from earlier.

**Confabulation** — solved by the **source anchor validator**. The cell must trace back to a real document.

**Corner cutting** — solved by the **completeness gate**. The pipeline cannot complete unless every required cell has been read.

**No normalization** — solved by the **normalization validator**. One-time items must be flagged.

Three failures. **Three gates.**

*[Click → slide 13]*

---

## Slide 13 — How Apex gets smarter (BARREL + Apex demo)

*[~40-50 seconds. Self-improvement layer. Apex demo plays in video panel.]*

Apex catches errors. But what makes Apex **get smarter**?

Every agent. Every gate. Every check — writes to a log. Reflection. Errors. Insights.

Then **BARREL** — Apex's learning engine — reads the log. Weekly. It looks for patterns.

When the same error appears **three or more times**, BARREL writes a new gate. The mistake becomes — technically — **impossible**.

This is how Apex gets smarter without us. Every error becomes a **wall the system cannot cross again**.

Watch the demo on the screen. This is the system in action.

*[Click → slide 14]*

---

## Slide 14 — SWF Manager Oversight (Setup)

*[~30-40 seconds. Simple English (B1) + CPO frame. Set up the case from the paper.]*

Now let me show you what L3 looks like in real practice. This case is from our September paper — the same paper Andrew Ang and our team wrote.

A sovereign wealth fund manages money through **75 external managers**. Different strategies. Different asset classes. Different geographies.

Their old way: **quarterly reviews**. Manual data. Late warnings. By the time a risk appeared in the report, the exposure had already moved.

They built an **L3 monitoring system**. Daily data from all 75 managers. Performance, holdings, risk metrics — all in one dashboard. Anomaly detection looking for unusual patterns.

Then one Tuesday, the dashboard found a problem with one of the 75 managers.

*[Click → slide 15]*

---

## Slide 15 — The Result · 47 Days

*[~30-40 seconds. Hero number 47, then implications.]*

The system flagged a **litigation threat** — affecting one of the 75 external managers.

It found the signal in a small district court filing — **47 days** before the official disclosure.

This is how L3 monitoring works. The system reads court filings, news, and regulatory data — across many sources, every day, in many languages. A human team cannot do this for 75 managers at once. The system can.

What happened next: the fund **reduced exposure**. They **avoided losses**. Other investors learned about the risk through normal disclosure channels — weeks later.

Other cases will be different. The early-warning window depends on the signal source. But this is what L3 monitoring made possible — **weeks** of additional reaction time, instead of being last to know.

The AI does not replace the investment committee. It gives them **time**.

*[Click → slide 16]*

---

## Slide 16 — Three Sentences (Close)

*[~45-60 seconds. Three numbered take-away sentences. Slow, deliberate.]*

I want to leave you with three sentences.

**One.** AI in investing today is mostly L1 and L2. There is a real path to L3 and L4 — and we have been walking it on live capital since Q1 2025.

**Two.** This journey produced three things — **a year of real returns on live capital**, a **framework co-written with Andrew Ang**, and an **architecture our team rolled into production**.

**Three.** The framework is **published**. The track record is **real**. The architecture is **ready**. Now we scale.

*[Click → slide 17]*

---

## Slide 17 — Thank you

*[~25-30 seconds. Closing. Slow, confident, eye contact.]*

Thank you.

The journey from **Assisted** — through **Agentic** — toward **Autonomous**.

Built with **Andrew Ang**. For **institutional capital** that demands more than *"trust the box."*

I'm **Assyl Akhmet**. Find me after the talk if you want to see what **L4** looks like in your portfolio.

*[End — applause]*
